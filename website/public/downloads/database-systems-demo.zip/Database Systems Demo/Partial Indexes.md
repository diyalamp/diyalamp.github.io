# Partial Indexes

A partial index stores only rows that satisfy its predicate. It helps when an important query repeatedly targets a small subset of a large table.

## Example

```sql
CREATE INDEX orders_open_idx
    ON orders (customer_id, created_at DESC)
    WHERE status = 'open';
```

A query with `WHERE status = 'open' AND customer_id = 42` can use this index. PostgreSQL must be able to infer the index predicate from the query when it plans the statement.

- [ ] Test the exact query shape in [[Query Plans]].
- [ ] Compare index size and write overhead in [[Index Maintenance]].
