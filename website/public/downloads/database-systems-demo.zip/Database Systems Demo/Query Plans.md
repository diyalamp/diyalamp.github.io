# Query Plans

A query plan is the database's chosen route to the result. A sequential scan can be a good choice when the query needs a large share of a table.

## Compare before and after

```sql
EXPLAIN (ANALYZE, BUFFERS)
SELECT id FROM orders WHERE customer_id = 42;
```

- Compare estimated and actual row counts.
- Check buffer hits and reads alongside elapsed time.
- Repeat with representative parameters and data volume.

`ANALYZE` runs the statement. Use a safe test environment for statements that change data. Compare [[Composite Indexes]] and [[Covering Indexes]] when testing an alternative access path.
