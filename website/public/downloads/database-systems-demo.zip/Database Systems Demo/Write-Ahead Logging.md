# Write-Ahead Logging

A write-ahead log records changes before their data pages reach durable storage. After a crash, the database uses the log to replay changes that the data files have yet to reflect.

## Example

An order insert can change both a table page and several index pages. With synchronous commit, PostgreSQL normally flushes the required log records before confirming the commit. The table and index pages can be written later.

Each additional index in [[Database Indexes]] can add work to the write path. See [[Index Maintenance]] for what to measure.
