# B-tree Indexes

A B-tree keeps index entries sorted. The engine navigates the tree to find a starting key, then walks nearby entries for a range.

## Example

On an index of `created_at`, a query for one day can seek to midnight and scan until the next midnight. If the query reads most rows, a sequential scan may cost less.

## Design check

- [ ] Use half-open ranges for adjacent time windows.
- [ ] Compare a narrow range with a wide one in [[Query Plans]].

For queries with more than one key, see [[Composite Indexes]].
