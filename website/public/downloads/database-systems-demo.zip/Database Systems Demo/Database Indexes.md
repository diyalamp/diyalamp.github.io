# Database Indexes

An index gives the database a way to find rows without scanning the whole table. Design it around a query you actually run: its filters, ordering, and limit.

## One query, one index

The order feed loads the latest 20 orders for one customer. Index by customer first, then by newest order.

```sql
CREATE INDEX orders_customer_feed_idx
    ON orders (customer_id, created_at DESC, id DESC);
```

The final column breaks timestamp ties. The same order in the query lets the planner consider stopping after 20 rows.

## Where to go next

- [[B-tree Indexes]] explains ordered lookups and range scans.
- [[Composite Indexes]] explains why column order matters.
- [[Covering Indexes]] shows when a read can skip the table.
- [[Partial Indexes]] keeps an index focused on a subset of rows.
- [[Query Plans]] shows how to verify what the database actually did.

## Before adding an index

- [ ] Capture the query and its current execution plan.
- [ ] Check whether an existing index already serves it.
- [ ] Compare reads, writes, and storage after the change.
