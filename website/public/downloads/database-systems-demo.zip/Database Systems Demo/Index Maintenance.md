# Index Maintenance

Indexes take storage and can add work to inserts and updates. Evaluate them against a representative workload before deciding which ones to keep.

## Review checklist

- [ ] Compare the index size with the table size.
- [ ] Check index usage across a complete business cycle.
- [ ] Check uniqueness and constraint dependencies before removal.
- [ ] Measure insert latency and WAL volume after the change.

Use [[Database Indexes]] to record the query each index serves. [[Write-Ahead Logging]] explains one place where write overhead shows up.
