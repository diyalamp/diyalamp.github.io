# Covering Indexes

A covering index contains the values needed for a query. PostgreSQL can add payload columns with `INCLUDE` without making them part of the search key.

## Example

```sql
CREATE INDEX orders_receipt_idx
    ON orders (id) INCLUDE (total_cents);
```

This is a candidate for `SELECT total_cents FROM orders WHERE id = 42`. PostgreSQL still needs to establish visibility. It checks the heap when the visibility map cannot confirm that the page is all-visible.

Check the heap fetch count in [[Query Plans]]. See [[Transaction Isolation]] for why visibility matters.
