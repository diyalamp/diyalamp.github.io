# Transaction Isolation

Isolation controls what concurrent transactions can observe. PostgreSQL uses multiversion concurrency control so a query reads row versions visible to its snapshot.

## Example

At Read Committed, two SELECT statements in one transaction can see different committed data. At Repeatable Read, they generally use the same transaction snapshot.

An entry from [[Database Indexes]] still has to lead to a row version visible to the reader. [[Covering Indexes]] explains when PostgreSQL can make that check without fetching the row from the heap.
