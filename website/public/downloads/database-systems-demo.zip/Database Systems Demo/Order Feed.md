# Order Feed

The order feed shows each customer's newest orders first. It uses the last row's timestamp and ID as a cursor so tied timestamps produce a stable order.

## Next-page query

```sql
SELECT id, created_at
FROM orders
WHERE customer_id = :customer
  AND (created_at, id) < (:last_time, :last_id)
ORDER BY created_at DESC, id DESC
LIMIT 20;
```

Here `:customer`, `:last_time`, and `:last_id` are client parameters. The ordering columns are non-null, and the ID is unique.

See [[Database Indexes]] for the matching index and [[Composite Indexes]] for the column order.
