# Composite Indexes

A multicolumn B-tree orders keys from left to right. In `(customer_id, created_at DESC, id DESC)`, orders for the same customer are grouped and already sorted newest first.

## Example

```sql
SELECT id, created_at
FROM orders
WHERE customer_id = 42
ORDER BY created_at DESC, id DESC
LIMIT 20;
```

A filter on `created_at` alone has no fixed customer prefix. Compare its plan separately before assuming the same index will be efficient.

See [[Order Feed]] for a stable pagination cursor and [[B-tree Indexes]] for the ordering model.
